import 'dart:ui' as ui;

import 'package:ProjetWebFlutter/main.dart' as entrypoint;

Future<void> main() async {
  if (true) {
    await ui.webOnlyInitializePlatform();
  }
  entrypoint.main();
}
