package com.example.ProjetWebFlutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
